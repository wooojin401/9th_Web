import { Outlet } from "react-router-dom";

const HomeLayout = () => {
  return (
    //부모 페이지의 공통 레이아웃
    <div className="h-dvh flex flex-col">
      <nav className="bg-gray-300">
        <h1 className="text-pink 500">돌려돌려 LP판</h1>
      </nav>
      <main className="flex-1 bg-black-400">
        <Outlet />
      </main>
      <footer>푸터입니다</footer>
    </div> //하위경로 /login의 내용이 이 위치에 렌더링
  );
};

export default HomeLayout;
/*
부모 라우트 컴포넌트(HomePage.tsx)는 자신의 children으로 정의된 자식 라우트 컴포넌트가 
어디에 나타나야할지 지정해줘야함. 이 역할을 하는 것이 Outlet 컴포넌트
 */
