const NotFoundPage = () => {
  return <div>NotFound</div>;
};

export default NotFoundPage;
