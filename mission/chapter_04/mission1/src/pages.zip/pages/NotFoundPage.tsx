import type { ReactElement } from "react";

export default function NotFoundPage(): ReactElement {
  return <div>못찾겠다 꾀꼬리</div>;
}
